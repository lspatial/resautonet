"""
This module (data) provides two datasets for tests. See details for data function.

"""