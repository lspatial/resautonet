
from resautonet.peranalysis import perAnaCls